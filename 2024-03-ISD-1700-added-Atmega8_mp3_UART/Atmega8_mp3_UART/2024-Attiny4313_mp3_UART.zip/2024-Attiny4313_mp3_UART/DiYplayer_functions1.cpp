/*
* DiYplayer_functions1.cpp
*
* Created: 2022-01-08 15:28:20
*  Author: abuam
*/
 #include <avr/io.h>
 #include <avr/power.h>
 #include <avr/sleep.h>
 #include <inttypes.h>
 #include <util/delay.h>
 #include <stdlib.h>
 #include <avr/pgmspace.h>
 #include <avr/wdt.h>
 #include <avr/interrupt.h>
#include "DiYplayer_functions1.h"


